  #Login or Sign Up Menu
def displayLogin_or_SignUp_Menu():
  print("\nCovid-19 Vaccination Registration Application")
  print("\nWelcome User! Please select your action from the options below by inputing the number. (Ex: Input 1 for the login option) ")
  print("====================================")
  print("1. Login")
  print("2. Sign up")
  print("3. Admin Login Menu")
  print("4. Quit\n")

def Public_User_Menu():
  print('')
  print('Public User Menu')
  print("====================================")
  print("1. Update Medical History")
  print("2. Update Covid-19 status")
  print("3. Update Occupation")
  print("4. User Info")
  print("5. Confirm Appointment")
  print('6. Log Out') 

def Admin_Menu():
  print('')
  print('Admin Menu')
  print("====================================")
  print("1. View all user")
  print("2. Add New Vaccination Center")
  print("3. Assign Appointment")
  print("4. Log Out")