# *********************************************************
# Program: main.py
# Course: PSP0101 PROBLEM SOLVING AND PROGRAM DESIGN
# Class: TC1V / TL4L
# Trimester: 2110
# Year: 2021/22 Trimester 1
# Member_1: 1211102975 | LOI XINYI | 1211102975@student.mmu.edu.my |0174886183
# Member_2: 1211102687 | EMILY PHANG RU YING | 1211102687@student.mmu.edu.my |0122270304
# Member_3: 1211102806 | ONG KWANG ZHENG | 1211102806@student.mmu.edu.my |0173684493
# Member_4: 1211103039 | OOI YI SIANG | 1211103039@student.mmu.edu.my |0124829822
# Task Distribution
# Member_1:Main, High Low Risk Catogarize , Covid Status, Login Authentication , Occupation, Signup Menu, User Info
# Member_2:Flowchart, Admin, Admin User Info, Assign Appointment, Confirm Appointment, Menu, Public User, Vaccination Center List
# Member_3:Flowchart, Medical History
# Member_4:Preloaded users
# *********************************************************
import loginauthentication, menu, signupmenu, admin, publicuser, preloadeduser,vaccinationCenterList, csv

#Loop for main page
exit = 0
while exit == False:
    current_user = None
    menu.displayLogin_or_SignUp_Menu() 
    option = int(input("Please enter the number: "))
    if option == 1: #Login
        current_user = loginauthentication.LoginMenu() # this function returns userID
        #to store current user's userID
        publicuser.publicuserloop(current_user) 
        exit= False
    elif option == 2: #Sign Up
        signupmenu.SignUpMenu() 
        exit = False
    elif option == 3: #Admin Login
        admin.AdminLogin()
        admin.adminloop()
        exit = False
        
    elif option == 4: #Quit
        print('Exiting...')
        #Source: https://realpython.com/python-csv/
        #To rewrite and store user data in csv file 
        with open('preloadeduser.csv','w', newline = '') as f:
          writer = csv.writer(f)
          writer.writerow(['username' , 'age' , 'userID' , 'phone number' , 'address' , 'postcode' , 'gender' , 'occupation' , 'medical history','covid-19 status', 'appointmentbool', 'time', 'date', 'vaccination center', 'job risk', 'count', 'RSVP'])
          writer.writerows(preloadeduser.userDataList)
        with open('KualaLumpurList.csv','w', newline = '') as f:
          writer = csv.writer(f)
          writer.writerow(['username' , 'userID' , 'phone number' , 'time', 'date', 'vaccination center', 'user risk', 'RSVP'])
          writer.writerows(vaccinationCenterList.KualaLumpurList)
        with open('ShahAlamList.csv','w', newline = '') as f:
          writer = csv.writer(f)
          writer.writerow(['username' , 'userID' , 'phone number' , 'time', 'date', 'vaccination center', 'user risk', 'RSVP'])
          writer.writerows(vaccinationCenterList.ShahAlamList)
        with open('MMUCyberjayaList.csv','w', newline = '') as f:
          writer = csv.writer(f)
          writer.writerow(['username' , 'userID' , 'phone number' , 'time', 'date', 'vaccination center', 'user risk', 'RSVP'])
          writer.writerows(vaccinationCenterList.MMUCyberjayaList)
        quit()
    else: 
        print("Error. Please enter a number from the options above.")
        print("Redirecting back to login...\n")
        exit = False

