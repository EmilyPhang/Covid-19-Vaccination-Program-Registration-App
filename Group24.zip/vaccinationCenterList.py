import csv  

file = open('KualaLumpurList.csv', 'r',newline='') #Read KualaLumpurList from KualaLumpurList.csv
datareader = csv.reader(file, delimiter=',',skipinitialspace=True)
tempKualaLumpurList=list()
for row in datareader:
  tempKualaLumpurList.append(list(row)) 
del tempKualaLumpurList[0]
KualaLumpurList = tempKualaLumpurList


file = open('ShahAlamList.csv', 'r',newline='') #Read ShahAlamList from ShahAlamList.csv
datareader = csv.reader(file, delimiter=',',skipinitialspace=True)
tempShahAlamList=list()
for row in datareader:
  tempShahAlamList.append(list(row)) 
del tempShahAlamList[0]
ShahAlamList = tempShahAlamList

file = open('MMUCyberjayaList.csv', 'r',newline='') #Read MMUCyberjayaList from MMUCyberjayaList.csv
datareader = csv.reader(file, delimiter=',',skipinitialspace=True)
tempMMUCyberjayaList=list()
for row in datareader:
  tempMMUCyberjayaList.append(list(row))
del tempMMUCyberjayaList[0]
MMUCyberjayaList = tempMMUCyberjayaList

vaccinationCenterList=[
  #[center number,center postcode ,vacination center name, center capacity]
  ['vaccination center 1', 40000, 'Kuala Lumpur',   1000,   [None]], #vaccinationCenterList[4] contains vac center user list
  ['vaccination center 2', 50000, 'Shah Alam ',     1000,   [None]], 
  ['vaccination center 3', 60000, 'MMU Cyberjaya',  500,    [None]]
]

vaccinationCenterList[0][4] = KualaLumpurList
vaccinationCenterList[1][4] = ShahAlamList
vaccinationCenterList[2][4] = MMUCyberjayaList


def addNewCenter(): #To add new vaccination centers to vaccinationCenterList
  NewCenterList = list()
  NewCenterList.append('vaccination center ' + input("Please enter your center number: "))
  NewCenterList.append(int(input("Please enter center postcode: ")))
  NewCenterList.append(input("Please enter your vacination center name: "))
  NewCenterList.append(int(input("Please enter center capacity: ")))
  NewCenterList.append([])
  vaccinationCenterList.append(NewCenterList)
