
import menu , medicalhistory , covidstatus , userinfo, occupation, highlowriskcatogarize, ConfirmAppointment, assignAppointment


#loop for public user after user successfully login
def publicuserloop(userID):
    exit = False
    while exit == False:
        menu.Public_User_Menu() 
        user_menu_option = int(input('Please enter a number: '))
        if user_menu_option == 1: #update medical history
            medicalhistory.Medical_History(userID) 
            assignAppointment.appoinmentBool(userID) #update user's appoinmentbool
            exit = False
        elif user_menu_option ==2: #update covid-19 status
          covidstatus.covid_status(userID)
          assignAppointment.appoinmentBool(userID) #update user's appoinmentbool
          exit = False
        elif user_menu_option ==3: #update occupation
          occupation.occupationmenu() 
          occupation.updateoccupation(userID) 
          highlowriskcatogarize.job_risk(userID) #update user's job risk
          highlowriskcatogarize.high_low_risk(userID) #update user's risk
          exit = False
        elif user_menu_option ==4: #view user's info
          userinfo.UserInfo(userID)
          exit = False
        elif user_menu_option==5: #confirm appointment
          ConfirmAppointment.confirmAppointment(userID)
          exit = False  
        elif user_menu_option == 6: #log out
          print('Logging Out...')
          break   
        else:
          print("Please enter the number of the options available.")

      