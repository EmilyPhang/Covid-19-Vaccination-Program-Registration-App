import csv  

file = open('preloadeduser.csv', 'r',newline='') #To read preloaded users from preloadeduser.csv
#Source: https://stackoverflow.com/questions/24606650/reading-csv-file-and-inserting-it-into-2d-list-in-python
datareader = csv.reader(file, delimiter=',',skipinitialspace=True)
tempUserDataList = list()
for row in datareader:
  tempUserDataList.append(list(row)) 
del tempUserDataList[0]
userDataList = tempUserDataList
for row in range(len(userDataList)): 
  userDataList[row][1] = int(userDataList[row][1])
  userDataList[row][5] = int(userDataList[row][5])
  if userDataList[row][10] == 'True':
    userDataList[row][10] = True
  elif userDataList[row][10] == 'False':
    userDataList[row][10] = False

#userDataList = [
   # [username0 , age1 , userID2 , phone number3 , address4 , postcode5 , gender6 , occupation7 , medical history8,covid-19 status9, appointmentbool10, time11, date12, vaccination center13, job risk14, user risk15, RSVP16]


