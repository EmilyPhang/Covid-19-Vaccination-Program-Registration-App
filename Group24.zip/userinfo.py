
from preloadeduser import userDataList

def UserInfo(userID):
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      print('')
      print(f"Welcome {userDataList[userRow][0]}!")
      print('====================================')
      print('View User Info')
      print('====================================')
      print(f'Username: {userDataList[userRow][0]} ')
      print(f'Age: {userDataList[userRow][1]} ')
      print(f'UserID: {userDataList[userRow][2]} ')
      print(f'Phone Number: {userDataList[userRow][3]}')
      print(f'Address: {userDataList[userRow][4]}')
      print(f'Postcode: {userDataList[userRow][5]}')
      print(f'Gender: {userDataList[userRow][6]}')
      print(f'Occupation: {userDataList[userRow][7]}')
      print('')
      print('====================================')
      print('Medical History')
      print('====================================')
      if userDataList[userRow][8] == '': #if user's medical history is empty
        print('Medical History not updated.')
      else:
        print("Are you feeling sick today ? "+ userDataList[userRow][8][0] )
        print("Are you exhibiting any covid-19 symptons such as coughing, loss of smell, loss of taste and difficulty breathing? " + userDataList[userRow][8][1])
        print("Do you have any bleeding disorder? " + userDataList[userRow][8][2])
        print("Do you had medical problems such as diabetes ,asthma or others? "+ userDataList[userRow][8][3])
        print("Do you have any severe allergic reactions? "+ userDataList[userRow][8][4])
      print('Vaccine Appointment')
      print('====================================')
      if userDataList[userRow][10] == False or userDataList[userRow][10] == None or userDataList[userRow][11] == '': #if user's appointmentbool = False or appointmentbool = None or user's appointment time is empty
        print('No vaccine appointment.')
      else:
        print(f'Vaccination Center: {userDataList[userRow][13]}')
        print(f'Date: {userDataList[userRow][12]}')
        print(f'Time: {userDataList[userRow][11]}')
        if userDataList[userRow][16] == "": #if user has not update his/her RSVP
          print('Please confirm your appointment.')
        elif userDataList[userRow][16] == "N":
          print('Appointment rejected.')
        elif userDataList[userRow][16] == "Y":
          print('Appointment confirmed.')
        

      