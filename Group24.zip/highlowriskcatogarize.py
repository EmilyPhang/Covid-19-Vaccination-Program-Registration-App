
from preloadeduser import userDataList
'''
High to Low Risk Ranking
for occupation 
1. Community Services, Health-care Worker
2. Factory Workers, Air Stewardess,Waitress/Waiter
3. Transportation Drivers,Food Delivery
4. Students above 18y/o, Teachers
5. Others
1-2 = High Risk Job
3-5 = Low Risk Job

High Risk for medical history
if userDataList[userRow][8][2] == 'y' (bleeding disorder)
if userDataList[userRow][8][3] == 'y' (medical problems such as diabetes, asthma and others)
if userDataList[userRow][8][4] == 'y' (severe allergic reactions)

High Risk for age
if userDataList[userRow][1] >= 60
'''
def job_risk(userID): #based on user's occupation
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      if userDataList[userRow][7] == 'Health-care Worker' or userDataList[userRow][7] =='Community Services' or userDataList[userRow][7] == 'Factory Workers' or userDataList [userRow][7] == 'Waitress/Waiter' or userDataList[userRow][7] == 'Air Stewardess':
        userDataList[userRow][14] = 'High Risk Job'
      else:
        userDataList[userRow][14] = 'Low Risk Job'
 
def high_low_risk(userID): #based on user's age, medical history, occupation
  count = 0
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      if userDataList[userRow][1] >= 60:
        count+=1
      if userDataList[userRow][8][2] == 'Y':
        count+=1
      if userDataList[userRow][8][3] == 'Y':
        count+=1
      if userDataList[userRow][8][4] == 'Y':
        count+=1
      if userDataList[userRow][14] == 'High Risk Job':
        count+=1
      if count >=3:
        userDataList[userRow][15] = 'High Risk User'    
      elif count <3:
        userDataList[userRow][15] = 'Low Risk User'

