from preloadeduser import userDataList
import vaccinationCenterList, datetime

def appoinmentBool(userID):  #Check if user can have appointment or not based on first two question in medical history (feeling sick today, covid-19 symptons) and covid-19 status.
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      if userDataList[userRow][8][0] == 'Y' or userDataList[userRow][8][1]== 'Y' or userDataList[userRow][9] == 'under quarantine':
         userDataList[userRow][10] = False #cannot have appointment
      else:
         userDataList[userRow][10] = True #can have appointment
        
  
def addUserListToSpecificVacCenterList (centerlist,userDataList, userRow): #add user's info to their respective vaccination center
  tempUserList = list(userDataList[userRow]) #store userRow's userDataList as temporaryUserList 

  del tempUserList[1] #delete age from temporary user list
            
  del tempUserList[3:10] #delete address , postcode , gender , occupation , medical history,covid-19 status, appointmentbool from temporary user list

  del tempUserList[6] #delete job risk from temporary user list
                 
  centerlist.append(tempUserList)
# [username0 ,  userID1 , phone number2 , time3, date4, vaccination center5,  user risk6, RSVP7]   


def assignAppointment(): #assign appointment by considering whether appointmentbool is True , if user's time is empty , user's postcode and whether vaccination center still has empty slots
  for userRow in range(len(userDataList)):
    if userDataList[userRow][10] == True:
      if userDataList[userRow][11] == '':
        if 40000<= userDataList[userRow][5] < 50000:
          if len(vaccinationCenterList.KualaLumpurList) < 1000:
            assign_date = datetime.datetime.today() + datetime.timedelta(days=7)
            userDataList[userRow][12] = assign_date.strftime("%d/%m/%Y")
            userDataList[userRow][11] = '10:00AM'
            userDataList[userRow][13] = 'Kuala Lumpur'
            addUserListToSpecificVacCenterList (vaccinationCenterList.KualaLumpurList,userDataList, userRow)
            
          else:
            print('Kuala Lumpur Vaccination Center reached max capacity.')
            
            
        elif 50000<= userDataList[userRow][5] < 60000:
          if len(vaccinationCenterList.ShahAlamList) < 1000:
            assign_date = datetime.datetime.today() + datetime.timedelta(days=7)
            userDataList[userRow][12] = assign_date.strftime("%d/%m/%Y")
            userDataList[userRow][11] = '02:00PM'
            userDataList[userRow][13] = 'Shah Alam'
            addUserListToSpecificVacCenterList (vaccinationCenterList.ShahAlamList,userDataList, userRow)
          else:
            print('Shah Alam Vaccination Center reached max capacity.')
            
        elif 60000<= userDataList[userRow][5] < 70000:
          if len(vaccinationCenterList.MMUCyberjayaList) < 500:
            assign_date = datetime.datetime.today() + datetime.timedelta(days=7)
            userDataList[userRow][12] = assign_date.strftime("%d/%m/%Y")
            userDataList[userRow][11] = '03:00PM'
            userDataList[userRow][13] = 'MMU Cyberjaya'
            addUserListToSpecificVacCenterList (vaccinationCenterList.MMUCyberjayaList,userDataList, userRow)
          else:
            print('MMU Cyberjaya Vaccination Center reached max capacity.')
             
        elif len(vaccinationCenterList.vaccinationCenterList)>3: #check if new vaccination center is added
          for vacCenterRow in range(3,len(vaccinationCenterList.vaccinationCenterList)):
            if int(vaccinationCenterList.vaccinationCenterList[vacCenterRow][1]) <= userDataList[userRow][5] < int(vaccinationCenterList.vaccinationCenterList[vacCenterRow][1])+10000: #check user's postcode
              if len(vaccinationCenterList.vaccinationCenterList[vacCenterRow][4]) < int(vaccinationCenterList.vaccinationCenterList[vacCenterRow][3]): #check if there's still empty slots for user list in the specific vaccination center 

                assign_date = datetime.datetime.today() + datetime.timedelta(days=7)
                userDataList[userRow][12] = assign_date.strftime("%d/%m/%Y")
                userDataList[userRow][11] = '10:00AM'
                userDataList[userRow][13] = f'{vaccinationCenterList.vaccinationCenterList[vacCenterRow][2]}'
                addUserListToSpecificVacCenterList (vaccinationCenterList.vaccinationCenterList[vacCenterRow][4],userDataList, userRow)
                print(vaccinationCenterList.vaccinationCenterList)
  print('Vaccination Appointment successfully assigned.')  
               
def AppointmentSlotsNotification(): #notify admin if there's empty slots in any vaccination center
  if len(vaccinationCenterList.KualaLumpurList) < 1000:
    print('Empty Slots available in Kuala Lumpur Vaccination Center.')
  if len(vaccinationCenterList.ShahAlamList) < 1000:
    print('Empty Slots available in Shah Alam Vaccination Center.')
  if len(vaccinationCenterList.MMUCyberjayaList) < 500:
    print('Empty Slots available in MMU Cyberjaya Vaccination Center.')
  if len(vaccinationCenterList.vaccinationCenterList)>3:
          for vacCenterRow in range(3,len(vaccinationCenterList.vaccinationCenterList)):
            if len(vaccinationCenterList.vaccinationCenterList[vacCenterRow][4]) < int(vaccinationCenterList.vaccinationCenterList[vacCenterRow][3]):
              print(f"Empty Slots available in {vaccinationCenterList.vaccinationCenterList[vacCenterRow][2]} Vaccination Center.")

  
  
            
            
        

    



#empty slot notify admin
# [username0 , age1 , userID2 , phone number3 , address4 , postcode5 , gender6 , occupation7 , medical history8,covid-19 status9, appointmentbool10, time11, date12, vaccination center13, job risk14, user risk15, RSVP16]