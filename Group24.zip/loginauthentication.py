from preloadeduser import userDataList



#Login Authentication 
def LoginMenu():
    print("\nLogin Menu")
    print("====================================")
    
    #UserID Comparison
    exit = False
    while exit == False:
        userID = str(input("Please enter your userID: "))
        for userRow in range(len(userDataList)): 
            
            if userID == userDataList[userRow][2]: #Check if userID is in userDataList
                print("UserID found.\n")
                
                #phoneNumber Comparison
                phoneNumber = str(input("Please enter your phone number: "))
                if phoneNumber == userDataList[userRow][3]:
                    print("Phone Number is correct. ")
                    print(f"Welcome {userDataList[userRow][0]}!")
                    exit = True
                    break  #break away from for loop
                else:
                    print("Phone Number is incorrect.")
                    break 
            else:
                continue # Continue checking userID row by row when userRow does not match
        else: #if for loop fail
            print("UserID not found.\n") #exit is still false so repeat the while loop
    else: #if while loop fails or when exit = True
        print("Redirecting to Public User Menu...")
        return userID #as output
        
      
        