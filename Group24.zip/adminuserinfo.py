from preloadeduser import userDataList
import vaccinationCenterList
from datetime import datetime

def viewAllUser():
  print("Admin: View All Users")
  print("====================================")
  print("")
  for userRow in range(len(userDataList)):
    print(userDataList[userRow])
  print('')
  print('Sorted according to Age')
  print("====================================")
  print("")
  sortedAge = sorted(userDataList, key = lambda x:int(x[1])) #Source : https://stackoverflow.com/questions/18563680/sorting-2d-list-python/18564382
  for userRow in range(len(sortedAge)):
    print(sortedAge[userRow])
  print('')
  print('Sorted according to postcode')
  print("====================================")
  print("")
  sortedPostcode = sorted(userDataList, key = lambda x:int(x[5]))
  for userRow in range(len(sortedPostcode)):
    print(sortedPostcode[userRow])
  print('')
  print('Sorted according to Risk Factor')
  print("====================================")
  print("")
  
  
  print('High Risk: ')
  for userRow in range(len(userDataList)):
    if userDataList[userRow][15] == 'High Risk User':
      print(userDataList[userRow])

  print('Low Risk: ')
  for userRow in range(len(userDataList)):
    if userDataList[userRow][15] == 'Low Risk User':
      print(userDataList[userRow])
      
  print("")
  print('Sorted according to appointment date and time')
  print("====================================")
  print("")
  print("Kuala Lumpur Vaccination Center: ")

  tempsortedtimeKL = sorted(vaccinationCenterList.KualaLumpurList, key=lambda x: datetime.strptime(x[3],"%I:%M%p"))
  sorteddatetimeKL = sorted(tempsortedtimeKL, key=lambda x: datetime.strptime(x[4], "%d/%m/%Y"))
  for userRow in range(len(sorteddatetimeKL)):
    print(sorteddatetimeKL[userRow])
  
  print("")
  print("Shah Alam Vaccination Center: ")

  tempsortedtimeSH = sorted(vaccinationCenterList.ShahAlamList, key=lambda x: datetime.strptime(x[3],"%I:%M%p"))
  sorteddatetimeSH = sorted(tempsortedtimeSH, key=lambda x: datetime.strptime(x[4], "%d/%m/%Y"))
  for userRow in range(len(sorteddatetimeSH)):
    print(sorteddatetimeSH[userRow])
  print("")
  print("MMU Cyberjaya Vaccination Center: ")
  tempsortedtimeMMU = sorted(vaccinationCenterList.MMUCyberjayaList, key=lambda x: datetime.strptime(x[3],"%I:%M%p"))
  sorteddatetimeMMU = sorted(tempsortedtimeMMU, key=lambda x: datetime.strptime(x[4], "%d/%m/%Y"))
  for userRow in range(len(sorteddatetimeMMU)):
    print(sorteddatetimeMMU[userRow])

  if len(vaccinationCenterList.vaccinationCenterList)>3: #Check if there's new vaccination center besides the hard-coded ones 
    for vacCenterRow in range(3,len(vaccinationCenterList.vaccinationCenterList)):
      print("")
      print(f"{vaccinationCenterList.vaccinationCenterList[vacCenterRow][2]} Vaccination Center: ")
      if vaccinationCenterList.vaccinationCenterList[vacCenterRow][4] == []: #if user appointment list in new vaccination center's list is empty
        print("No User Appointments yet.")
      else:#if user appointment list in new vaccination center's list has users
        tempsortedtime = sorted(vaccinationCenterList.vaccinationCenterList[vacCenterRow][4], key=lambda x: datetime.strptime(x[3],"%I:%M%p"))
        sorteddatetime = sorted(tempsortedtime, key=lambda x: datetime.strptime(x[4], "%d/%m/%Y"))
        for userRow in range(len(sorteddatetime)):
          print(sorteddatetime[userRow])
        
        
  else:
    pass
      


