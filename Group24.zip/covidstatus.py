from preloadeduser import userDataList

def covid_status(userID):
  print('1. Normal')
  print('2. Under quarantine')
  print("====================================")
  print("Please enter a number.")
  option = int(input('Covid-19 status: '))
  if option == 1:
    status = 'normal'
  elif option == 2:
    status = 'under quarantine'
  
  print('Covid-19 status updated.\n')
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
     userDataList[userRow][9] = status #set user's covid-19 status in user's list to status
