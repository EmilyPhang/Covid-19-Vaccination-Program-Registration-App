from preloadeduser import userDataList


def Medical_History(userID):
  print("Please Update Your Medical History by typing 'Y' for Yes and 'N' for No")
  a = str(input("Are you feeling sick today ? ")).upper()
  b = str(input("Are you exhibiting any covid-19 symptons such as coughing, loss of smell, loss of taste and difficulty breathing? ")).upper()
  c = str(input("Do you have any bleeding disorder? ")).upper()
  d = str(input("Do you had medical problems such as diabetes ,asthma or others? ")).upper()
  e = str(input("Do you have any severe allergic reactions? ")).upper()

  print('Medical History update complete.')
  medical_history = a + b + c + d + e
  for userRow in range(len(userDataList)): #update user's medical history
    if userID == userDataList[userRow][2]:
     userDataList[userRow][8] = medical_history





 

  


