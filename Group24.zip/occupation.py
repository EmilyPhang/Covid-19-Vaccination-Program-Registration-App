from preloadeduser import userDataList

def occupationmenu():
  print('')
  print('Occupation List')
  print("====================================")
  print('1. Health-care Worker')
  print('2. Community Services')
  print('3. Food Delivery')
  print('4. Transportation Drivers ')
  print('5. Factory Workers')
  print('6. Waitress/Waiter')
  print('7. Air Stewardess')
  print('8. Students above 18 y/o')
  print('9. Teachers')
  print('10. Others') 

def updateoccupation(userID):
  occupation_option = int(input('Please key in the number of your occupation:'))

  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      if occupation_option == 1:
        userDataList[userRow][7] = 'Health-care Worker'
      elif occupation_option == 2:
        userDataList[userRow][7] = 'Community Services'
      elif occupation_option == 3:
        userDataList[userRow][7] = 'Food Delivery'
      elif occupation_option == 4:
        userDataList[userRow][7] = 'Transportation Drivers'
      elif occupation_option == 5:
        userDataList[userRow][7] = 'Factory Workers'
      elif occupation_option == 6:
        userDataList[userRow][7] = 'Waitress/Waiter'
      elif occupation_option == 7:
        userDataList[userRow][7] = 'Air Stewardess'
      elif occupation_option == 8:
        userDataList[userRow][7] = 'Students above 18y/o'
      elif occupation_option == 9:
        userDataList[userRow][7] = 'Teachers'
      elif occupation_option == 10:
        userDataList[userRow][7] = 'Others'
   
      


      



  
