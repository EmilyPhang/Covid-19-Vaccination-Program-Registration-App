import menu, adminuserinfo, vaccinationCenterList, assignAppointment


AdminDataList = [
  ["Daniel Tan" , 123456 ]
]

def AdminLogin():
    print("\nAdmin Login Menu")
    print("====================================")
    #Loop for admin login authentication
    exit = False
    while exit == False:
      AdminUserName = str(input("Please enter your username: "))
      if AdminUserName == AdminDataList[0][0]: #check if AdminUserName is userName in Admin DataList
        print("UserName found.\n")
        password = int(input("Please enter your password: "))
        if password == AdminDataList[0][1]: #check if password is password in Admin DataList
          print("Password is correct")
          print(f"Welcome {AdminUserName}!")
          exit = True
        
        else:
          print("Password is incorrect.\n")
            
      else:
        print("UserName not found.\n")  
    else: #When exit == True
      print("Redirecting to Admin Menu...")
      

#loop for admin main page
def adminloop():
    exit = False
    while exit == False:
        menu.Admin_Menu() 
        admin_menu_option = int(input('Please enter a number: '))
        if admin_menu_option == 1: #View All User
          adminuserinfo.viewAllUser() 
          exit = False
        elif admin_menu_option ==2: #Add New Vaccination Center
          vaccinationCenterList.addNewCenter() 
          exit = False
        elif admin_menu_option ==3: #Assign Appointment
          assignAppointment.assignAppointment()
          assignAppointment.AppointmentSlotsNotification()
          exit = False

        elif admin_menu_option == 4: #Log Out
          print('Logging Out...')
          exit = True 
        else: #if user enter unavailable options
          print("Please enter the options available.") 
        
 
        
        
    
    
