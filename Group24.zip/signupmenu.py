from preloadeduser import userDataList


def SignUpMenu():
  print("\nSign Up Menu")
  print("====================================")
  NewUserDataList = list()
  NewUserDataList.append(input("Please enter your username: "))
  NewUserDataList.append(int(input("Please enter your age: ")))
  NewUserDataList.append(input("Please enter your userID: "))
  NewUserDataList.append(input("Please enter your phone number: "))
  NewUserDataList.append(input("Please enter your address: "))
  NewUserDataList.append(int(input("Please enter your postcode: ")))
  NewUserDataList.append(input("Please enter your gender: "))
  NewUserDataList.append(None) #unknown occupation
  NewUserDataList.append('') #unknown medical history
  NewUserDataList.append('') #unknown covid-19 status
  NewUserDataList.append(None) #unknown appointmentbool
  NewUserDataList.append('') #unknown time
  NewUserDataList.append('') #unknown date
  NewUserDataList.append('') #unknown vaccination center
  NewUserDataList.append('') #unknown job risk
  NewUserDataList.append('') #unknown user risk
  NewUserDataList.append('') #unknown RSVP
  userDataList.append(NewUserDataList)
  print('Sign up complete! ')











  
  




