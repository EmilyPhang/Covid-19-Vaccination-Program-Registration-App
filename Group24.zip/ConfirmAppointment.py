from preloadeduser import userDataList
from vaccinationCenterList import KualaLumpurList , ShahAlamList, MMUCyberjayaList, vaccinationCenterList

def confirmAppointment(userID):
  for userRow in range(len(userDataList)):
    if userID == userDataList[userRow][2]:
      if userDataList[userRow][11] == '':
        print('No vaccine appointment.')
      else:
        print(f'Vaccination Center: {userDataList[userRow][13]}')
        print(f'Date: {userDataList[userRow][12]}')
        print(f'Time: {userDataList[userRow][11]}')
        userDataList[userRow][16] = input("Confirm Appointment:").upper()
        
        
        if userDataList[userRow][16] == 'Y':
          checkVacCenterList(KualaLumpurList,userID) #check if user's list is in KualaLumpurList
          checkVacCenterList(ShahAlamList,userID) #check if user's list is in ShahAlamList
          checkVacCenterList(MMUCyberjayaList,userID) #check if user's list is in MMUCyberjayaList
          if len(vaccinationCenterList)>3:
            for vacCenterRow in range(3,len(vaccinationCenterList)): #check if user's list is in new vaccination center's list
              checkVacCenterList(vaccinationCenterList[vacCenterRow][4],userID)
          print("Appointment confirmed.")
        elif userDataList[userRow][16] == 'N':
          userDataList[userRow][13] == "" #clear vaccination center from user's list
          userDataList[userRow][12] == "" #clear date from user's list
          userDataList[userRow][11] == "" #clear time from user's list
          print('Vaccine appointment rejected.')



def checkVacCenterList(centerlist, userID): #check if user's list belongs in the centerlist
  for userRow in range(len(centerlist)):
    if userID == centerlist[userRow][1]:
      centerlist[userRow][7] = 'Y'
      
